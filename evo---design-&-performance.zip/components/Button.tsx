import React from 'react';
import { ArrowRight } from 'lucide-react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
  variant?: 'primary' | 'secondary';
  fullWidth?: boolean;
}

export const Button: React.FC<ButtonProps> = ({ 
  children, 
  variant = 'primary', 
  fullWidth = false,
  className = '',
  ...props 
}) => {
  const baseStyles = "relative inline-flex items-center justify-center px-8 py-4 text-xs font-bold tracking-[0.2em] uppercase transition-all duration-500 overflow-hidden rounded-sm group";
  
  const variants = {
    primary: "bg-white text-black border border-white hover:bg-zinc-200 hover:shadow-[0_0_30px_rgba(255,255,255,0.5)]",
    secondary: "bg-transparent text-white border border-white/20 hover:border-white/40 hover:bg-white/5 hover:shadow-[0_0_20px_rgba(255,255,255,0.1)]"
  };

  const widthClass = fullWidth ? "w-full" : "";

  return (
    <button 
      className={`${baseStyles} ${variants[variant]} ${widthClass} ${className}`}
      {...props}
    >
      <span className="relative z-10 flex items-center gap-3">
        {children}
        {variant === 'primary' && <ArrowRight className="w-3 h-3 transition-transform duration-300 group-hover:translate-x-1" />}
      </span>
    </button>
  );
};