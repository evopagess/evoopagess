import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { motion } from 'framer-motion';
import { Button } from './Button';
import { CheckCircle } from 'lucide-react';
import { FormData, FormStatus } from '../types';

export const LeadForm: React.FC = () => {
  const { register, handleSubmit, formState: { errors } } = useForm<FormData>();
  const [status, setStatus] = useState<FormStatus>(FormStatus.IDLE);

  const onSubmit = async (data: FormData) => {
    setStatus(FormStatus.SUBMITTING);
    await new Promise(resolve => setTimeout(resolve, 1500));
    setStatus(FormStatus.SUCCESS);
  };

  if (status === FormStatus.SUCCESS) {
    return (
      <section id="contact" className="py-32 bg-zinc-900/10 border-t border-white/5">
        <div className="container mx-auto px-4 text-center">
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="max-w-xl mx-auto p-12 border border-white/10 bg-black/50 backdrop-blur-md rounded-sm shadow-[0_0_50px_-20px_rgba(255,255,255,0.2)]"
          >
            <CheckCircle className="w-12 h-12 text-white/80 mx-auto mb-6 font-thin drop-shadow-[0_0_10px_rgba(255,255,255,0.5)]" />
            <h3 className="text-3xl font-serif italic mb-4 text-white">Aplicação Enviada</h3>
            <p className="text-zinc-500 font-light">
              Entraremos em contato em breve.
            </p>
          </motion.div>
        </div>
      </section>
    );
  }

  return (
    <section id="contact" className="py-32 relative bg-zinc-950 overflow-hidden">
      <div className="container mx-auto px-4 relative z-10">
        <div className="flex flex-col lg:flex-row gap-20">
          
          <div className="lg:w-1/2 pt-4">
            <span className="text-xs font-bold tracking-widest text-zinc-500 uppercase mb-4 block">Chamada para Ação</span>
            <h2 className="text-4xl md:text-5xl font-medium mb-10 tracking-tight text-white leading-tight">
              Pronto para elevar o nível da sua <span className="text-silver drop-shadow-[0_0_10px_rgba(255,255,255,0.15)]">presença digital?</span>
            </h2>
            <p className="text-zinc-400 text-lg leading-relaxed mb-8 font-light">
              Atendemos um número limitado de projetos por mês para garantir a máxima performance e exclusividade em cada entrega. Se você busca uma página que transmita autoridade e suporte sua escala de vendas, vamos conversar.
            </p>
          </div>

          <div className="lg:w-1/2">
            <div className="relative p-1 rounded-sm bg-gradient-to-b from-white/10 to-transparent">
              <div className="bg-black/80 backdrop-blur-xl p-8 rounded-sm border border-white/5 relative overflow-hidden">
                <form onSubmit={handleSubmit(onSubmit)} className="space-y-8 relative z-10">
                  
                  <div className="group">
                    <label className="block text-xs font-bold uppercase tracking-widest text-zinc-300 mb-3 group-focus-within:text-white transition-colors">1. Qual o seu nome e o nome da sua empresa/projeto?</label>
                    <input 
                      {...register("name", { required: true })}
                      className="w-full bg-transparent border-b border-zinc-700 py-4 text-lg text-white focus:border-white/80 focus:shadow-[0_10px_20px_-10px_rgba(255,255,255,0.1)] focus:outline-none transition-all placeholder:text-zinc-600 font-serif italic"
                      placeholder="Sua resposta aqui..."
                      autoComplete="off"
                    />
                    {errors.name && <span className="text-red-500 text-xs block mt-2">Obrigatório</span>}
                  </div>

                  <div className="group">
                    <label className="block text-xs font-bold uppercase tracking-widest text-zinc-300 mb-3 group-focus-within:text-white transition-colors">2. Qual o seu objetivo principal hoje?</label>
                    <select 
                      {...register("objective", { required: true })}
                      className="w-full bg-transparent border-b border-zinc-700 py-4 text-white focus:border-white/80 focus:outline-none transition-all appearance-none rounded-none text-lg"
                    >
                      <option value="" className="text-zinc-500 bg-black">Selecione uma opção...</option>
                      <option value="launch" className="bg-black">Lançamento</option>
                      <option value="evergreen" className="bg-black">Perpétuo</option>
                      <option value="positioning" className="bg-black">Posicionamento</option>
                    </select>
                  </div>

                  <div className="group">
                     <label className="block text-xs font-bold uppercase tracking-widest text-zinc-300 mb-4 group-focus-within:text-white transition-colors">3. Você já investe em tráfego pago (anúncios)?</label>
                     <div className="flex gap-8">
                        <label className="flex items-center gap-3 cursor-pointer group/radio">
                            <input {...register("trafficInvested", { required: true })} type="radio" value="yes" className="sr-only peer" />
                            <div className="w-5 h-5 border border-zinc-500 rounded-full peer-checked:bg-white peer-checked:border-white peer-checked:shadow-[0_0_10px_rgba(255,255,255,0.5)] transition-all"></div>
                            <span className="text-zinc-300 peer-checked:text-white text-base group-hover/radio:text-white">Sim</span>
                        </label>
                        <label className="flex items-center gap-3 cursor-pointer group/radio">
                            <input {...register("trafficInvested", { required: true })} type="radio" value="no" className="sr-only peer" />
                            <div className="w-5 h-5 border border-zinc-500 rounded-full peer-checked:bg-white peer-checked:border-white peer-checked:shadow-[0_0_10px_rgba(255,255,255,0.5)] transition-all"></div>
                            <span className="text-zinc-300 peer-checked:text-white text-base group-hover/radio:text-white">Não</span>
                        </label>
                     </div>
                  </div>

                  <div className="group">
                    <label className="block text-xs font-bold uppercase tracking-widest text-zinc-300 mb-3 group-focus-within:text-white transition-colors">4. Verba disponível para o projeto?</label>
                    <select 
                      {...register("revenue", { required: true })}
                      className="w-full bg-transparent border-b border-zinc-700 py-4 text-white focus:border-white/80 focus:outline-none transition-all appearance-none rounded-none text-lg"
                    >
                      <option value="" className="text-zinc-500 bg-black">Selecione uma faixa...</option>
                      <option value="starting" className="bg-black">&lt; 10k</option>
                      <option value="scaling" className="bg-black">10k - 50k</option>
                      <option value="established" className="bg-black">50k - 100k</option>
                      <option value="high-level" className="bg-black">&gt; 100k</option>
                    </select>
                  </div>

                  <div className="group">
                    <label className="block text-xs font-bold uppercase tracking-widest text-zinc-300 mb-3 group-focus-within:text-white transition-colors">5. Seu WhatsApp para contato?</label>
                    <input 
                      {...register("whatsapp", { required: true })}
                      className="w-full bg-transparent border-b border-zinc-700 py-4 text-lg text-white focus:border-white/80 focus:shadow-[0_10px_20px_-10px_rgba(255,255,255,0.1)] focus:outline-none transition-all placeholder:text-zinc-600 font-mono"
                      placeholder="(DDD) 9..."
                    />
                    {errors.whatsapp && <span className="text-red-500 text-xs block mt-2">Obrigatório</span>}
                  </div>

                  <div className="pt-10">
                    <Button type="submit" fullWidth disabled={status === FormStatus.SUBMITTING} className="shadow-[0_0_20px_-5px_rgba(255,255,255,0.1)] hover:shadow-[0_0_30px_-5px_rgba(255,255,255,0.3)]">
                      {status === FormStatus.SUBMITTING ? 'Processando...' : 'SOLICITAR ORÇAMENTO'}
                    </Button>
                  </div>

                </form>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};