import React from 'react';
import { motion } from 'framer-motion';

export const Navbar: React.FC = () => {
  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <motion.nav 
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.8 }}
      className="fixed top-6 left-0 right-0 z-50 flex justify-center px-4"
    >
      <div className="glass-panel px-6 py-3 rounded-full flex items-center gap-8 shadow-2xl bg-black/60 backdrop-blur-xl border border-white/10 relative overflow-hidden">
        
        <span className="font-serif italic font-bold text-lg text-white pr-4 border-r border-white/10">EVO</span>
        
        <div className="hidden md:flex gap-6 text-xs font-medium uppercase tracking-widest text-zinc-400">
          <button onClick={() => scrollTo('solution')} className="hover:text-white transition-colors">Solução</button>
          <button onClick={() => scrollTo('contact')} className="hover:text-white transition-colors">Contato</button>
        </div>

        <button 
          onClick={() => scrollTo('contact')}
          className="ml-2 px-4 py-1.5 text-xs font-bold text-black bg-white rounded-full hover:bg-zinc-200 transition-colors"
        >
          INICIAR
        </button>
      </div>
    </motion.nav>
  );
};