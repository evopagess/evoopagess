import React, { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Button } from './Button';
import { ChevronDown } from 'lucide-react';

export const Hero: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sectionRef = useRef<HTMLElement>(null);

  const scrollToForm = () => {
    document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    const section = sectionRef.current;
    if (!canvas || !section) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let drops: number[] = [];
    
    // HTML/Tech symbols specific to the niche
    const symbols = ['< >', 'div', '{ }', 'px', '01', 'rem', '()', '/>', 'src', 'id', 'npm', 'var', 'if', '&&', '90+', 'ms'];

    const initCanvas = () => {
      // Set canvas dimensions to match the section exactly
      canvas.width = section.offsetWidth;
      canvas.height = section.offsetHeight;

      const columns = Math.floor(canvas.width / 20);
      
      // Re-initialize drops only if column count changes significantly or empty
      if (drops.length === 0 || Math.abs(drops.length - columns) > 5) {
        drops = new Array(columns).fill(1);
      }
    };

    const draw = () => {
      // Create trailing effect with semi-transparent black
      ctx.fillStyle = 'rgba(0, 0, 0, 0.05)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Set text color to a visible silver/zinc shade
      ctx.fillStyle = '#a1a1aa'; // Zinc-400 (Visible Silver)
      ctx.font = '14px monospace';

      for (let i = 0; i < drops.length; i++) {
        // Randomly select a symbol
        const text = symbols[Math.floor(Math.random() * symbols.length)];
        
        // Draw the text
        ctx.fillText(text, i * 20, drops[i] * 20);

        // Reset drop to top randomly or if it goes off screen
        // Use canvas.height to ensure it goes all the way down
        if (drops[i] * 20 > canvas.height && Math.random() > 0.975) {
          drops[i] = 0;
        }

        // Increment Y coordinate
        drops[i]++;
      }
    };

    // Initial sizing
    initCanvas();

    const interval = setInterval(draw, 50); // 20FPS

    // Use ResizeObserver to handle both window resize and content height changes
    const resizeObserver = new ResizeObserver(() => {
      initCanvas();
    });
    
    resizeObserver.observe(section);

    return () => {
      clearInterval(interval);
      resizeObserver.disconnect();
    };
  }, []);

  return (
    <section ref={sectionRef} className="relative min-h-screen flex flex-col justify-center items-center pt-20 overflow-hidden bg-black selection:bg-white/30">
      
      {/* Background Asset - Modern Silver/Dark Metallic CSS */}
      <div className="absolute inset-0 z-0 bg-zinc-950 pointer-events-none">
        
        {/* Base Darkness Layers */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#000000,#1a1a1a,#000000)] opacity-100"></div>
        
        {/* Atmospheric Glows */}
        <div className="absolute inset-0 overflow-hidden">
           <div className="absolute -top-[50%] -left-[50%] w-[200%] h-[200%] bg-[conic-gradient(from_0deg_at_50%_50%,_#000000_0deg,_#18181b_100deg,_#000000_180deg,_#18181b_280deg,_#000000_360deg)] opacity-40 blur-[80px] animate-slow-spin"></div>
        </div>
        
        <div className="absolute top-0 left-0 right-0 h-[500px] bg-gradient-to-b from-zinc-800/10 to-transparent blur-3xl"></div>
        <div className="absolute bottom-0 right-0 w-[800px] h-[800px] bg-zinc-800/10 rounded-full blur-[120px]"></div>
        
        {/* HTML Code Rain Canvas - MOVED HERE to be ON TOP of gradients */}
        <canvas 
          ref={canvasRef} 
          className="absolute inset-0 opacity-25 mix-blend-screen z-10"
        />

        {/* Final Fade to ensure text readability */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-transparent to-black z-20"></div>
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_transparent_0%,_#000000_100%)] opacity-80 z-20"></div>
      </div>
      
      <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-15 pointer-events-none mix-blend-overlay z-0"></div>
      
      <div className="container mx-auto px-4 z-30 relative text-center">
        
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="mb-8"
        >
          <span className="inline-block px-3 py-1 text-[10px] font-bold tracking-[0.4em] text-zinc-400 uppercase border border-zinc-800 rounded-full bg-black/40 backdrop-blur-md shadow-2xl">
            EVO - Design & Performance
          </span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
          className="text-4xl md:text-6xl lg:text-7xl font-medium tracking-tight mb-8 text-white mix-blend-difference max-w-5xl mx-auto leading-[1.1] drop-shadow-2xl"
        >
          Sua página de vendas com <br className="hidden md:block" />
          <span className="font-serif italic font-light text-silver opacity-90">design de alto padrão</span> <br className="hidden md:block" />
          e carregamento instantâneo.
        </motion.h1>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.6 }}
          className="h-px w-24 bg-gradient-to-r from-transparent via-zinc-500 to-transparent mx-auto mb-8"
        ></motion.div>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="text-base md:text-lg text-zinc-400 max-w-3xl mx-auto mb-12 font-light leading-relaxed tracking-wide"
        >
          Paramos de perder seu dinheiro com sites lentos e amadores que espantam seus clientes. 
          Criamos a estrutura técnica para você escalar seu infoproduto com <span className="text-zinc-200 font-medium">autoridade</span>.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1 }}
        >
          <Button onClick={scrollToForm} className="shadow-[0_0_40px_-10px_rgba(255,255,255,0.2)] hover:shadow-[0_0_60px_-10px_rgba(255,255,255,0.4)] transition-shadow duration-500 bg-white/5 border-white/20 backdrop-blur-sm text-white hover:bg-white/10">
            SOLICITAR ORÇAMENTO
          </Button>
        </motion.div>

      </div>

      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2, duration: 1.5 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 opacity-50 z-30"
      >
        <span className="text-[10px] uppercase tracking-widest text-zinc-600">Scroll</span>
        <ChevronDown className="w-4 h-4 text-zinc-600 animate-bounce" />
      </motion.div>
    </section>
  );
};